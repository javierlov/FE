﻿function createEmbed(PDFName)
{
    document.write('<embed type="application/pdf" id="iPDF" src="' + PDFName + '#toolbar=1&navpanes=0&scrollbar=0" width="100%" height="475px" ></embed>');
}